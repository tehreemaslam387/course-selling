declare module 'joi-browser' {
  import Joi from 'joi';

  // Export the Joi namespace
  export = Joi;
}
