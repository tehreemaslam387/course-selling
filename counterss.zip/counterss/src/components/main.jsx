import React, { Component } from 'react';
import Products from './products'
import Courses from './courses'
import WhyUs from './whyUs';
import BottomBar from './Bottom';
class Main extends Component {
    
    render() { 
        return (
            <div>
        <div className='container1'>
            <h1 className='sidebar'> Explore the 
                World of 
                Growth & Success!
            </h1>
            <button type="button" class="btn btn-outline-warning">Get Started</button>
        </div>
           <div className='container2'>
                 <h4>Why choose<br />
                     AlphaCourses?</h4>
        <WhyUs />
        <Products />
               <h3>What they say about<br />
                     our company</h3>
        <div className='container3'></div>
               <h3>Upcoming Courses</h3>
        <Courses />
        <div className='container4'></div>
        <BottomBar />
             </div> 
             </div>
             );
    }
}
 
export default Main;