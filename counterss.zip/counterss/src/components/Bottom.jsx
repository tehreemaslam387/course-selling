import React, { Component } from 'react';
class BottomBar extends Component {
    render() { 
        return (
            <div className='PageContainer'>
                <div class="content">
  <p className='para'>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
  The point of using Lorem Ipsum is that it has a more-or-less normal distribution.
  ing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
  <div class="header">
  <nav class="navigation">
    <ul>
      <li><a>Home</a></li>
      <li><a>About Us</a></li>
      <li><a>Contact Us</a></li>
    </ul>
  </nav>
  <div class="contact-info">
    <div class="phone">
      <strong>Phone</strong>
      <p>+91 9911197929</p>
    </div>
    <div class="email">
      <strong>Email</strong>
      <p>hello@aptigainz.com</p>
    </div>
  </div>
</div><hr className="separator" />
                <p style={{color : 'white'}}>Copyright © 2023 AptiGainz. All Rights Reserved.</p>
                </div>
 </div>
        );
    }
}
 
export default BottomBar;