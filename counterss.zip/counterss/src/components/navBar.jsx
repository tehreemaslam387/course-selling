import React, { Component } from 'react';
import {Link} from 'react-router-dom'
class Navbar extends Component {
   
    render() { 
        return (
           
            <ul className="nav">
                <a className="navbar-brand"></a>
                <li className="nav-item">
    <Link to = '/main' className="nav-link active">Home</Link>
  </li>
  <li className="nav-item">
    <Link to = '/aboutUs' className="nav-link">About Us</Link>
  </li>
  <li className="nav-item">
    <Link to = '/contactUs' className="nav-link" >Contact Us</Link>
  </li>
  <li className="nav-item">
          <Link to="/login" className="b button"style={{ color: 'black' }}>Login</Link>
        </li>
</ul>


        );
    }
}
 
export default Navbar;