import React, { Component } from 'react';
class Courses extends Component {
    render() { 
        return (
            <div className='containers'>
        <div className="containertetra log">
        <p className='heading'>Cryptocurrency</p>
        <p className='textt'>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
        </p>
        </div>
        <div className="containertetra log">
            <p className='heading'>Email Marketing</p>
            <p className='textt'>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
            </p>
        </div>
        <div className="containertetra log">
            <p className='heading'>Interview Mastery</p>
        <p className='textt'>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
            </p>
        </div>
        <div className="containertetra log">
            <p className='heading'>Content Writing</p>
            <p className='textt'>
       Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
            </p>
        </div>
        </div>
        );
    }
}
 
export default Courses;