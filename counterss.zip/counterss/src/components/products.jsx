import React, { Component } from 'react';
class Products extends Component {
    render() { 
        return (
            <div>
            <h3>Our Top AlphaCourses< br/>
               Products</h3>
        <body>
  <div className="container-row">
    <div className="clickable log1">
        <h> Premium </h>
        <p>All levels&nbsp;&nbsp;&nbsp;0 Lessons.<br />
        0 quizes&nbsp;&nbsp;&nbsp;0 Students</p>
        <hr className="separator" />
        <p1>10 weeks</p1>
        <h>$122.00</h>
        <button className='btnBuy btn-sm'> Buy Now</button>
    </div>
    <div className="clickable log2">
        <h> Prime </h>
        <p>All levels&nbsp;&nbsp;&nbsp;0 Lessons.<br />
        0 quizes&nbsp;&nbsp;&nbsp;0 Students</p>
        <hr className="separator" />
        <p1>10 weeks</p1>
        <h>$53.00</h>
        <button className='btnBuy btn-sm'> Buy Now</button>
    </div>
    <div className="clickable log3">
        <h > Pro </ h>
        <p>All levels&nbsp;&nbsp;&nbsp;0 Lessons.<br />
        0 quizes&nbsp;&nbsp;&nbsp;0 Students</p>
        <hr className="separator" />
        <p1>10 weeks</p1>
        <h>$23.00</h>
        <button className='btnBuy btn-sm'> Buy Now</button>
    </div>
    <div className="clickable log4">
        <h> Plus </h>
        <p>All levels&nbsp;&nbsp;&nbsp;0 Lessons.<br />
        0 quizes&nbsp;&nbsp;&nbsp;0 Students</p>
        <hr className="separator" />
        <p1>10 weeks</p1>
        <h>$11.00</h>
        <button className='btnBuy btn-sm'> Buy Now</button>
    </div>
  </div>
</body>
</div>
        );
    }
}
 
export default Products;