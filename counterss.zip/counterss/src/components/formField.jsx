import React, { Component } from 'react';
class FormField extends Component {
    render() {
        const {name, label, value, type, onChange, errors } = this.props;

        return (
            <div className="form-group ">
                <i className="fa fa-user" aria-hidden="true"></i>
                <label htmlFor={label}></label>
                <input
                    value={value}
                    onChange={onChange}
                    name={name}
                    type={type}
                    className="form-control"
                    placeholder={`Enter ${label}`}
                    id={name}
                />
                {errors && <div className="alert alert-danger">{errors}</div>}
            </div>
        );
    }
}

export default FormField;


