import React, { Component } from 'react';
import Joi from 'joi-browser';
import Form from './form';
import {Link } from 'react-router-dom'
import BottomBar from './Bottom';
class Login  extends Form {
state = {
    data : { email : '', password : ''},
    errors : {}
};
schema = {
    email : Joi.string().required().label("Email"),
    password : Joi.string().required().label("Password")
}


doSubmit = () => {
     this.props.history.push('/')
}
   
    render() { 
        return (
            <div className='login-page'>
                <div className='container'>
            <form 
            onSubmit={this.handleOnSubmit}>
            <h1 className='line'>Login</h1>
                    {this.renderInput("email","Email", "email", )}
                    {this.renderInput("password","Password", "password")}
                <div className="form-group form-check">
               <label className="form-check-label">
             <input className="form-check-input" type="checkbox" /> Remember me
            </label>
                    </div>
                  <div> {this.renderButton("log In")}</div>
                  <Link to = '/register' className='reg' >Register</Link>
                </form>
                </div>
                <BottomBar />
                </div>
                
        );
    }
}
 
export default Login;