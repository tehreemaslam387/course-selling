import React, { Component } from 'react';
class contactUs extends Component {
  
    render() { 
        return ( <h1>Contact Us</h1>
        );
    }
}
 
export default contactUs;