import React, { Component } from 'react';
class WhyUs extends Component {
    render() { 
        return (
            <div className='containers'>
        <div className="containertetra logo1">
        <p className='heading'>Professional Courses</p>
        <p className='textt'>
        Learn professional skills and enhance your creativity that sets you apart from others
        </p>
        </div>
        <div className="containertetra logo2">
            <p className='heading'>Certification</p>
            <p className='textt'>
        Get certification after completion of the courses.
            </p>
        </div>
        <div className="containertetra logo3">
            <p className='heading'>Customer Support</p>
        <p className='textt'>
        We give fastest and best experience to our customers.
            </p>
        </div>
        <div className="containertetra logo4">
            <p className='heading'>Refer & Earn</p>
            <p className='textt'>
       Earn high commission on every referral 75% - 95%
            </p>
        </div>
        </div>
        );
    }
}
 
export default WhyUs;