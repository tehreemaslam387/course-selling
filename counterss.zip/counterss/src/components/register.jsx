import React, { Component } from 'react';
import Joi from 'joi-browser';
import Form from './form';
import BottomBar from './Bottom';
class Register extends Form {
    state = {
    data : { username: '', email : '', password : ''},
    errors : {}
};
schema = {
    username :Joi.string().required().label("Username"),
    email : Joi.string().required().label("Email"),
    password : Joi.string().required().label("Password")
}


doSubmit = () => {
     this.props.history.push('/')
}
   
    render() { 
        return (
            <div className='login-page'>
                <div className='container'>
            <form 
            onSubmit={this.handleOnSubmit}>
            <h1 className='line'>Login</h1>
                    {this.renderInput("email","Email", "email", )}
                    {this.renderInput("password","Password", "password")}
                    {this.renderInput("username","Username", "Username")}
                <div className="form-group form-check">
               <label className="form-check-label">
             <input className="form-check-input" type="checkbox" /> I accept the terms and conditions.
            </label>
                    </div>
                  <div> {this.renderButton("Register")}</div>
                </form>
                </div>
                <BottomBar />
                </div>
        );
    }
}
 
export default Register;