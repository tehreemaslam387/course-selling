import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';
import Main from './components/main';
import AboutUs from './aboutUs';
import ContactUs from './components/contactUs';
import Login from './components/login'
import Register from './components/register'
import Navbar from './components/navBar'; 

class App extends Component {
  render() {
    return (
      
          <div>
          <Navbar /> 
        <div>
          <Switch>
            <Route path="/main" component={Main} />
            <Route path="/aboutUs" component={AboutUs} />
            <Route path="/contactUs" component={ContactUs} />
            <Route path="/login" component={Login} />
            <Route path="/register" component={Register} />
            <Route path="/" exact component={Main} />
          </Switch>
          </div>

          </div>
    
  
    );
  }
}

export default App;
