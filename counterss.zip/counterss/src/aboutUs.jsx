import React, { Component } from 'react';
class aboutUs extends Component {
   
    render() { 
        return (<h1>About Us</h1>
        );
    }
}
 
export default aboutUs;